#include <stdio.h>

int main()
{
    int i1,i2;
    scanf("%d%d",&i1,&i2);
    i1>i2?printf("%d is greater",i1):printf("%d is greater",i2);

    return 0;
}
