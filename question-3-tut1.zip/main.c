
#include <stdio.h>

int main()
{
    int length;
    int breadth;
    int perimeter;
    
    printf("Enter the length and breadth of the rectangle: \n");
    scanf("%d%d",&length,&breadth);
    perimeter=length+breadth;
    printf("%d + %d =%d",length,breadth,perimeter);

    return 0;
}
