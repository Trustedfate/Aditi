#include <stdio.h>
void
findmax(int num1, int num2)
{
  if (num1 < num2)
    {
      printf ("Num 1 is greater\n");
    }
  else
    {
      printf ("Num 2 is greate\nr");
    }
}
void
findmin (int num1, int num2)
{
  if (num1 < num2)
    {
      printf ("Num 1 is smaller\n");
    }
  else
    {
      printf ("Num 2 is smaller\n");
    }
}
void
main ()
{
  int a, b;
  printf("Enter the values of a and b: ");
  scanf("%d%d",&a,&b);
  findmax (a, b);
  findmin(a,b);
}

