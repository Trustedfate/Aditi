#include <stdio.h>
void main()
{
    int n, k=1;
    scanf ("%d", &n);
    for (int i=1; i<=n; i++)
    {
        k*=i;
    }
    printf ("%d",k);
}