
#include <stdio.h>

int main()
{
    int length;
    int breadth;
    float area;
    
    printf("Enter length and breadth of rectangle: \n");
    scanf("%d%d",&length,&breadth);
    area=length*breadth;
    printf("%d * %d = %f\n",length,breadth,area);

    return 0;
}
