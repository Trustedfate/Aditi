#include <stdio.h>
#include<math.h>
int main()
{
    int base;
    int height;
    float area;
    printf("Enter the base and height of the triangle: \n");
    scanf("%d%d",&base,&height);
    
    area=(0.5)*base*height;
    printf("The area of the triangle = %f",area);
    
}
