#include <stdio.h>

int main()
{
    float cm,m,km;
    printf("Enter the number in centimeters: \n");
    scanf("%f",&cm);
    
    m = cm/100;
    km = cm/10000;
    printf("The measurement in m is :%.2f\n",m);
    printf("The measurement in km is :%.4f\n",km);

}
