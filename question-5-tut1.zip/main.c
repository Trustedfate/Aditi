#include <stdio.h>

int main()
{
    int radius,diameter;
    float area,circumference;
    printf("Enter the radius of the circle:\n");
    scanf("%d",&radius);
    diameter= 2*radius;
    area = 3.14*radius*radius;
    circumference = 2*3.14*radius;
    
    printf("The diameter of the circle is : %d\n",diameter);
    printf("The area of the circle is: %.2f\n",area);
    printf("The circumference of the circle is: %.1f\n",circumference);
    

    
}
