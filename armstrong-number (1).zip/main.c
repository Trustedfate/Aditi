#include <stdio.h>
#include <math.h>

int main()
{
    int n,m,b;
    float c=0;
    scanf ("%d", &n);
    m=n;
    int k=log10(n)+1;
    for (int i=0; i<=k; i++)
    {
        b=n%10;
        c+=pow(b,k);
        n=(int)n/10;
    }
    printf ("%0.0f", c);
    if (m==(int)c)
    {
        printf ("\nArmstrong number");
    }
    else
    {
        printf ("\nNot a armstrong number");
    }
}