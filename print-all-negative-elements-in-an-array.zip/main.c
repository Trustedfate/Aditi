#include <stdio.h>
int main()
{
    int i,marks[5]={1,-2,3,4,-5};
    for(i=0;i<=4;i++)
    {
        if(marks[i]<0)
        {
            printf("%d\n",marks[i]);
        }
    }
   return 0; 
}
