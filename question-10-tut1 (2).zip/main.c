#include <stdio.h>
#include <math.h>

int main()
{
    double number;
    double root;
    printf("Enter the number:\n");
    scanf("%lf",&number);
    
    root=sqrt(number);
    printf("The square root of the number of %.2lf = %.2lf\n",number,root);

    return 0;
}
