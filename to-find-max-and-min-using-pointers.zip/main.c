#include <stdio.h>
void findmaxmin(int num1,int num2,int *pmax,int *pmin)
{
    if (num1>num2)
    {
        *pmin=num2;
        *pmax=num1;
    }
    else
    {
        *pmin=num1;
        *pmax=num2;
    }
}
void main()
{
    int a=4,b=6;
    int max,min;
    findmaxmin(a,b,&max,&min);
    printf("Max between %d and %d = %d\n",a,b,max);
    printf("Min between %d and %d = %d\n",a,b,min);
   
}
