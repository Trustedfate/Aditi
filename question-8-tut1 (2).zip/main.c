#include <stdio.h>

int main()
{
    int days;
    int year;
    int weeks;
    printf("Enter the number of days:\n");
    scanf("%d",&days);
    
    year = (days / 365);
    weeks = (days % 365) / 7;
    days = days - ((year * 365) + (weeks));
    
    printf("%dyear\n%dweeks\n%ddays\n",year,weeks,days);

    return 0;
}
