
#include <stdio.h>

int main()
{
    int x;
    int y;
    int sum,modulus,sub,mul;
    float div;
    
    printf("Enter any two numbers:\n ");
    scanf("%d%d" ,&x,&y);
    
    sum=x+y;
    modulus=x%y;
    sub=x-y;
    mul=x*y;
    div=x/y;
    
    printf("\n");
    printf("The sum of numbers is: %d+%d = %d\n",x,y,sum);
    printf("The subtraction of numbers is: %d-%d = %d\n",x,y,sub);
    printf("The multiplication of numbers is: %d*%d = %d\n",x,y,mul);
    printf("The modulus of numbers is: %d %% %d = %d\n",x,y,sum);
    printf("The division of numbers is: %d / %d = %lf\n",x,y,div);
    
}
