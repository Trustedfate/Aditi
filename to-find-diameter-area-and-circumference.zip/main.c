#include <stdio.h>

void diameter(int r)
{
    
   
    int diameter;
    diameter = 2*r;
    printf("diameter= %d\n",diameter);
}
void circumference(int r)
{
   
    float circumference;
    circumference=2*3.14*r;
    printf("circumference= %.2f\n",circumference);
}
void area(int r)
{
  
   float area;
   area = 3.14*r*r;
   printf("area= %.2f\n",area);
}
int main()
{
    int r;
    printf("Enter the radius of the circle: ");
    scanf("%d",&r);
    diameter(r);
    circumference(r);
    area(r);
}
