#include <stdio.h>

int main()
{
    int n,a=0,b=1;
    printf("Enter a number",n);
    scanf("%d",&n);
    printf("\n");
    for(n>=0,i,i++);
    printf("%d")
    

    return 0;
}
