#include <stdio.h>

int main()
{
    float celsius;
    float fahrenheit;
    printf("Enter the temperature in fahrenheit:\n");
    scanf("%f",&fahrenheit);
    celsius = (fahrenheit-32) * 5/9;
    printf("The temperature in celsius: %.2f\n",celsius);

    return 0;
}
