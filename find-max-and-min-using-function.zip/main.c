#include <stdio.h>
void findminmax(int num1,int num2)
{
    if (num1>num2)
    {
        printf("Num1 is greater\nNum2 is smaller");
    }
    else
    {
        printf("Num2 is greater\nNum1 is smaller");
    }
}
int main()
{
    int a,b;
    printf("Enter the values of a and b: ");
    scanf("%d%d",&a,&b);
    findminmax(a,b);

    return 0;
}
