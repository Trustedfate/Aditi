#include <stdio.h>

int main()
{
    int angle1;
    int angle2;
    int thirdside;
    printf("Enter any two angles of triangle: \n");
    scanf("%d%d",&angle1,&angle2);
    
    thirdside=180-(angle1+angle2);
    printf("The third side of the triangle =%d\n",thirdside);
    

    return 0;
}
