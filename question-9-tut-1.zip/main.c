#include <stdio.h>
#include <math.h>

int
main ()
{
  int x;
  int y;
  float p;
  printf ("Enter the numbers:\n");
  scanf ("%d%d", &x, &y);
  p = pow (x, y);
  printf ("%f", p);



}
