#include <stdio.h>

int main()
{
    int a,b,c;
    printf("Enter the value of a: ");
    scanf("%d",&a);
    printf("Enter the value of b: ");
    scanf("%d",&b);
    printf("Enter the value of c: ");
    scanf("%d",&c);
    a>b&&a>c?printf("%d is greater than %d and %d",a,b,c):b>a&&b>c?printf("%d is greater than %d and %d",b,a,c):c>a&&c>b?printf("%d is greater than %d and %d",c,b,a):printf("Equal");
 

    return 0;
}
