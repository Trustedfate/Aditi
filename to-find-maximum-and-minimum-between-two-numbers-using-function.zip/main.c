#include <stdio.h>

void number(int a,int b)
{
    a>b?printf("a is greater"):printf("b is greater");
}
int main()
{
    int a,b;
    printf("Enter the numbers: ");
    scanf("%d%d",&a,&b);
    number(a,b);
}