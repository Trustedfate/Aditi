#include <stdio.h>

void cube()
{
    int a;
    scanf("%d",&a);
    printf("%d",a*a*a);
}
int main()
{
    cube();
}
