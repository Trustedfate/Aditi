
#include <stdio.h>

void main()
{
    int x;
    int y;
    int sum;
    printf("Enter any two numbers: \n");
    scanf("%d%d",&x,&y);
    sum=x+y;
    printf("%d + %d =%d\n",x,y,sum);

   
}
